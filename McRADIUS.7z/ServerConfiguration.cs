﻿using System;
namespace McRADIUS
{
    public class ServerConfiguration
    {
        public ServerConfiguration()
        {
        }
    }
}
